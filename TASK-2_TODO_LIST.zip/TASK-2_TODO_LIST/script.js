document.addEventListener('DOMContentLoaded', function () {
    const taskInput = document.getElementById('task');
    const addTaskButton = document.getElementById('addTask');
    const taskList = document.getElementById('taskList');
    const updateTaskButton = document.getElementById('updateTask');

    let selectedTask = null;

    // Add task function
    addTaskButton.addEventListener('click', function () {
        const taskText = taskInput.value.trim();

        if (taskText !== '') {
            const li = document.createElement('li');
            li.innerHTML = `
                <span>${taskText}</span>
                <button class="delete">Delete</button>
                <button class="update">Update</button>
            `;

            taskList.appendChild(li);

            // Clear the input field
            taskInput.value = '';

            // Delete task when the "Delete" button is clicked
            li.querySelector('.delete').addEventListener('click', function () {
                li.remove();
            });

            // Update task when the "Update" button is clicked
            li.querySelector('.update').addEventListener('click', function () {
                taskInput.value = li.querySelector('span').textContent;
                selectedTask = li;
                updateTaskButton.style.display = 'block';
            });
        }
    });

    // Update task function
    updateTaskButton.addEventListener('click', function () {
        if (selectedTask) {
            const taskText = taskInput.value.trim();
            if (taskText !== '') {
                selectedTask.querySelector('span').textContent = taskText;
                taskInput.value = '';
                updateTaskButton.style.display = 'none';
                selectedTask = null;
            }
        }
    });
});
